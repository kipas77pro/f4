#!/bin/bash

DOMAIN="aryablitar.filegear-sg.me"
CF_ID="lahseta19@gmail.com"
CF_KEY="3f485e550288defa9d0e97039eab598de1c58"
clear
echo "$DOMAIN"
echo "Cloudflare with Pointing"
echo "Enter your Host and IPVPS"

# Request user input for subdomain and VPS IP
read -rp "SUBDOMAIN : " -e sub
read -rp "IPVPS     : " -e IP

# Define full subdomain
SUB_DOMAIN="${sub}.${DOMAIN}"

echo "Memperbarui DNS untuk ${SUB_DOMAIN}"

# Get Zone ID
    ZONE=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones?name=${DOMAIN}&status=active" \
        -H "X-Auth-Email: ${CF_ID}" \
        -H "X-Auth-Key: ${CF_KEY}" \
        -H "Content-Type: application/json" | jq -r .result[0].id)

    if [ -z "$ZONE" ]; then
        echo "Error: Zone ID tidak ditemukan"
        exit 1
    fi

    # Get DNS Record ID
    RECORD=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records?name=${SUB_DOMAIN}" \
        -H "X-Auth-Email: ${CF_ID}" \
        -H "X-Auth-Key: ${CF_KEY}" \
        -H "Content-Type: application/json" | jq -r .result[0].id)

    # Create DNS record if not exists
    if [[ "${#RECORD}" -le 10 ]]; then
        RECORD=$(curl -sLX POST "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records" \
            -H "X-Auth-Email: ${CF_ID}" \
            -H "X-Auth-Key: ${CF_KEY}" \
            -H "Content-Type: application/json" \
            --data '{"type":"A","name":"'${SUB_DOMAIN}'","content":"'${IP}'","ttl":120,"proxied":false}' | jq -r .result.id)
    fi

    if [ -z "$RECORD" ]; then
        echo "Error: Pembuatan catatan DNS gagal"
        exit 1
    fi

    # Update DNS record
    RESULT=$(curl -sLX PUT "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records/${RECORD}" \
        -H "X-Auth-Email: ${CF_ID}" \
        -H "X-Auth-Key: ${CF_KEY}" \
        -H "Content-Type: application/json" \
        --data '{"type":"A","name":"'${SUB_DOMAIN}'","content":"'${IP}'","ttl":120,"proxied":false}')

    if [ "$(echo $RESULT | jq -r .success)" != "true" ]; then
        echo "Error: Pembaruan catatan DNS gagal"
        exit 1
    fi